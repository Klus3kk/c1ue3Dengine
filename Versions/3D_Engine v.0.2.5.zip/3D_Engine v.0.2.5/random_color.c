#include "random_color.h"
#include <stdlib.h>  // For rand() and RAND_MAX

// Generates a random float between 0.0 and 1.0
float randomFloat() {
    return (float)rand() / (float)RAND_MAX;
}

// Updates the color uniform in the shader
void updateShaderColor(GLuint shaderProgram) {
    float r = randomFloat();
    float g = randomFloat();
    float b = randomFloat();

    // Use the shader program before setting the uniform
    glUseProgram(shaderProgram);

    // Update the color uniform
    GLint colorLoc = glGetUniformLocation(shaderProgram, "inputColor");
    if (colorLoc != -1) {  // Check if the uniform location is found
        glUniform4f(colorLoc, r, g, b, 1.0f);  // Set the color
    }
}
