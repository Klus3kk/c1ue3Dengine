#include "ObjectManager.h"
#include <stdlib.h>
#include "Camera.h"
#include "Vectors.h"

ObjectManager objectManager;

void initObjectManager() {
    objectManager.capacity = 10;
    objectManager.objects = malloc(sizeof(Object3D) * objectManager.capacity);
    objectManager.count = 0;
}

void addObject(Camera* camera, ObjectType type) {
    float distanceInFront = 5.0f;
    Vector3 position = vector_add(camera->Position, vector_scale(camera->Front, distanceInFront));

    Object3D newObject;
    newObject.position = position;
    newObject.type = type;

    switch (type) {
    case OBJ_CUBE:
        newObject.data.cube = createCube(position);
        newObject.color = newObject.data.cube.color;
        break;
    case OBJ_SPHERE:
        newObject.data.sphere = createSphere(0.5f, 16, 8, position);
        newObject.color = newObject.data.sphere.color;
        break;
    case OBJ_PYRAMID:
        newObject.data.pyramid = createPyramid(position);
        newObject.color = newObject.data.pyramid.color;
        break;
    case OBJ_CYLINDER:
        newObject.data.cylinder = createCylinder(0.5f, 1.0f, 8, position);
        newObject.color = newObject.data.cylinder.color;
        break;
    }

    addObjectToManager(newObject);
}


void removeObject(int index) {
    if (index < 0 || index >= objectManager.count) return;

    // Clean up based on type
    switch (objectManager.objects[index].type) {
    case OBJ_CUBE:
        destroyCube(&objectManager.objects[index].data.cube);
        break;
    case OBJ_SPHERE:
        destroySphere(&objectManager.objects[index].data.sphere);
        break;
    case OBJ_PYRAMID:
        destroyPyramid(&objectManager.objects[index].data.pyramid);
        break;
    case OBJ_CYLINDER:
        destroyCylinder(&objectManager.objects[index].data.cylinder);
        break;
    }

    // Shift remaining objects down in the array
    for (int i = index; i < objectManager.count - 1; i++) {
        objectManager.objects[i] = objectManager.objects[i + 1];
    }
    objectManager.count--;
}

void cleanupObjects() {
    for (int i = 0; i < objectManager.count; i++) {
        removeObject(i);
    }
    free(objectManager.objects);
    objectManager.objects = NULL;
    objectManager.count = 0;
    objectManager.capacity = 0;
}

void addObjectToManager(Object3D newObject) {
    if (objectManager.count >= objectManager.capacity) {
        objectManager.capacity *= 2;
        objectManager.objects = realloc(objectManager.objects, objectManager.capacity * sizeof(Object3D));
    }

    objectManager.objects[objectManager.count++] = newObject;
}
