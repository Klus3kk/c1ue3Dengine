#pragma once
#include "3DObjects.h" 
#include "Camera.h"
typedef enum {
    OBJ_CUBE,
    OBJ_SPHERE,
    OBJ_PYRAMID,
    OBJ_CYLINDER
} ObjectType;

typedef struct {
    ObjectType type;
    union {
        Cube cube;
        Sphere sphere;
        Pyramid pyramid;
        Cylinder cylinder;
    } data;
    Vector3 position;
    Vector4 color;
} Object3D;

typedef struct {
    Object3D* objects;
    int count;
    int capacity;
} ObjectManager;

extern ObjectManager objectManager;

void initObjectManager();
void addObject(Camera* camera, ObjectType type);
void removeObject(int index);
void cleanupObjects();
void addObjectToManager(Object3D newObject);