#pragma once
#ifndef _3DOBJECTS_H_
#define _3DOBJECTS_H_

#include <GLFW/glfw3.h>
#include "Vectors.h"
typedef struct {
    GLuint vao; // Vertex Array Object ID
    GLuint vbo; // Vertex Buffer Object ID
    GLuint ebo; // Element Buffer Object ID
    Vector3 position; // Position of the cube
    Vector4 color;     // Color of the cube
} Cube;

Cube createCube();
void drawCube(const Cube* cube, Matrix4x4 viewMatrix, Matrix4x4 projMatrix);
void destroyCube(Cube* cube);

#endif