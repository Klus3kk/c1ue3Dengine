#pragma once
#include "Camera.h"
#include "Vectors.h"

void initFreeType();
void cleanupTextRendering();
void renderDebugInfo(const Camera* camera);
void cleanupTextRendering();