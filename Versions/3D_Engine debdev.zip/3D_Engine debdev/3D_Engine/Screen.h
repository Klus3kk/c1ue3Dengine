#pragma once

typedef struct {
	GLFWwindow* window;
	int width;
	int height;
	char title[100];
} Screen;

