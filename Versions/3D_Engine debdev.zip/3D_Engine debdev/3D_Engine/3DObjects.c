// 3DObjects.c
#include "3DObjects.h"
#include <glad/glad.h>  
#include "Vectors.h"
#include "Camera.h"
#include "random_color.h"
extern unsigned int shaderProgram;  // Ensure shaderProgram is accessible here

Cube createCube(Vector3 position) {
    Cube cube;
    float vertices[] = {
        -0.5f, -0.5f, -0.5f,  // Vertex 1
         0.5f, -0.5f, -0.5f,  // Vertex 2
         0.5f,  0.5f, -0.5f,  // Vertex 3
        -0.5f,  0.5f, -0.5f,  // Vertex 4
        -0.5f, -0.5f,  0.5f,  // Vertex 5
         0.5f, -0.5f,  0.5f,  // Vertex 6
         0.5f,  0.5f,  0.5f,  // Vertex 7
        -0.5f,  0.5f,  0.5f   // Vertex 8
    };
    unsigned int indices[] = {
        0, 1, 2, 2, 3, 0,  // Front face
        1, 5, 6, 6, 2, 1,  // Right face
        7, 6, 5, 5, 4, 7,  // Back face
        4, 0, 3, 3, 7, 4,  // Left face
        4, 5, 1, 1, 0, 4,  // Bottom face
        3, 2, 6, 6, 7, 3   // Top face
    };

    glGenVertexArrays(1, &cube.vao);
    glBindVertexArray(cube.vao);
    glGenBuffers(1, &cube.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, cube.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glGenBuffers(1, &cube.ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cube.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    cube.position = position;  // Set the position of the cube
    cube.color = (Vector4){ randomFloat(), randomFloat(), randomFloat(), 1.0 };  // RGBA color
    return cube;
}

void drawCube(const Cube* cube, Matrix4x4 viewMatrix, Matrix4x4 projMatrix) {
    glUseProgram(shaderProgram);

    int modelLoc = glGetUniformLocation(shaderProgram, "model");
    int viewLoc = glGetUniformLocation(shaderProgram, "view");
    int projLoc = glGetUniformLocation(shaderProgram, "projection");

    Matrix4x4 modelMatrix = translateMatrix(cube->position);  // Assuming translateMatrix is defined elsewhere

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, modelMatrix.data[0]);
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, viewMatrix.data[0]);
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, projMatrix.data[0]);

    // Set color
    GLint colorLoc = glGetUniformLocation(shaderProgram, "inputColor");
    glUniform4f(colorLoc, cube->color.x, cube->color.y, cube->color.z, cube->color.w);

    glBindVertexArray(cube->vao);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}



void destroyCube(Cube* cube) {
    glDeleteVertexArrays(1, &cube->vao);
    glDeleteBuffers(1, &cube->vbo);
    glDeleteBuffers(1, &cube->ebo);
}


