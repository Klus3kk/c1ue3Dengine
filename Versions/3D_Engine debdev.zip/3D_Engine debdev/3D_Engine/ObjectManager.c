#include "ObjectManager.h"
#include <stdlib.h>
#include "Camera.h"
#include "Vectors.h"
void initCubeManager() {
    cubeManager.capacity = 10;
    cubeManager.cubes = malloc(sizeof(Cube) * cubeManager.capacity);
    cubeManager.count = 0;
}

void addCube(Camera* camera) {
    float distanceInFront = 5.0f;  
    Vector3 cubePosition = vector_add(camera->Position, vector_scale(camera->Front, distanceInFront));
    Cube newCube = createCube(cubePosition);
    addCubeToManager(newCube);
}




void removeCube(int index) {
    if (index < 0 || index >= cubeManager.count) return;
    destroyCube(&cubeManager.cubes[index]); // Assuming a function to cleanup a Cube
    cubeManager.cubes[index] = cubeManager.cubes[--cubeManager.count];
}

void cleanupCubes() {
    for (int i = 0; i < cubeManager.count; i++) {
        destroyCube(&cubeManager.cubes[i]);
    }
    free(cubeManager.cubes);
    cubeManager.cubes = NULL;
    cubeManager.count = 0;
    cubeManager.capacity = 0;
}

void addCubeToManager(Cube newCube) {
    if (cubeManager.count >= cubeManager.capacity) {
        cubeManager.capacity *= 2;  
        cubeManager.cubes = realloc(cubeManager.cubes, cubeManager.capacity * sizeof(Cube));
    }

    cubeManager.cubes[cubeManager.count++] = newCube;  
}