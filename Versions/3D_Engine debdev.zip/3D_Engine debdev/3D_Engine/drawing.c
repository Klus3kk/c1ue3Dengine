#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "Screen.h"
#include "Vectors.h"
#include "3DObjects.h"
#include "shaders.h"
#include "Camera.h"
#include "ObjectManager.h"
#include "random_color.h"
#include "debug.h"
#include <ft2build.h>

Screen screen;
unsigned int shaderProgram;
Camera camera;

int viewLoc;
int projLoc;
void debug();
bool isRunning = true;  
bool debugPressed = false;  
bool debugMode = false;
bool cubePressed = false;

void setup() {
    screen.width = 1500;
    screen.height = 1000;
    strcpy(screen.title, "C1ue Engine v.0.2.0");

    initCamera(&camera);
    initCubeManager();  
}

void render() {
    glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    updateShaderColor(shaderProgram);

    Matrix4x4 viewMatrix = getViewMatrix(&camera);
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &viewMatrix.data[0][0]);

    float aspectRatio = (float)screen.width / screen.height;
    Matrix4x4 projMatrix = getProjectionMatrix(45.0f, (float)screen.width / screen.height, 0.1f, 100.0f);
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, &projMatrix.data[0][0]);

    for (int i = 0; i < cubeManager.count; i++) {
        drawCube(&cubeManager.cubes[i], viewMatrix, projMatrix);
    }

    glfwSwapBuffers(screen.window);
}




void update() {
    int state = glfwGetKey(screen.window, GLFW_KEY_E);
    static double lastFrame = 0.0;
    double currentFrame = glfwGetTime();
    float deltaTime = currentFrame - lastFrame; // Delta time for performance
    lastFrame = currentFrame;
    if (state == GLFW_PRESS) {
        printf("\nExiting...\n");
        exit(EXIT_SUCCESS);
    }
    // Example to add a cube with key press 'C'
    if (glfwGetKey(screen.window, GLFW_KEY_C) == GLFW_PRESS && !cubePressed) {
        addCube(&camera);
        cubePressed = true;
    }
    else if (glfwGetKey(screen.window, GLFW_KEY_C) == GLFW_RELEASE) {
        cubePressed = false;
    }
    // Keyboard input handling for camera movement
    if (glfwGetKey(screen.window, GLFW_KEY_W) == GLFW_PRESS) {
        processKeyboard(&camera, 1, deltaTime);
    }
    if (glfwGetKey(screen.window, GLFW_KEY_S) == GLFW_PRESS) {
        processKeyboard(&camera, 2, deltaTime);
    }
    if (glfwGetKey(screen.window, GLFW_KEY_A) == GLFW_PRESS) {
        processKeyboard(&camera, 3, deltaTime);
    }
    if (glfwGetKey(screen.window, GLFW_KEY_D) == GLFW_PRESS) {
        processKeyboard(&camera, 4, deltaTime);
    }
    if (glfwGetKey(screen.window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        processKeyboard(&camera, 5, deltaTime);
    }
    if (glfwGetKey(screen.window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) {
        processKeyboard(&camera, 6, deltaTime);
    }
}

void loop() {
    double lastX, lastY;
    glfwGetCursorPos(screen.window, &lastX, &lastY);
    while (!glfwWindowShouldClose(screen.window)) {
        glfwPollEvents();

        if (glfwGetKey(screen.window, GLFW_KEY_P) == GLFW_PRESS && !debugPressed) {
            debugMode = !debugMode; // Toggle debug mode
            debugPressed = true;
        }
        else if (glfwGetKey(screen.window, GLFW_KEY_P) == GLFW_RELEASE) {
            debugPressed = false;
        }

        if (isRunning) {
            glEnable(GL_DEPTH_TEST);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            update();
            render(); // Perform normal rendering

            double xpos, ypos;
            glfwGetCursorPos(screen.window, &xpos, &ypos);
            float xoffset = xpos - lastX;
            float yoffset = lastY - ypos;
            lastX = xpos;
            lastY = ypos;
            processMouseMovement(&camera, xoffset, yoffset, true);

            if (debugMode) {
                renderDebugInfo(&camera); // Render debug information if mode is active
            }
        }

        glfwSwapBuffers(screen.window); // Random flickering.....
    }
}



void end() {
    cleanupCubes();  
    cleanupTextRendering();
    glfwDestroyWindow(screen.window);
    glfwTerminate();
}

void info() {
    printf("Width: %d\n", screen.width);
    printf("Height: %d\n", screen.height);
    printf("Title: %s\n", screen.title);
    printf("OpenGL version: %s\n", glGetString(GL_VERSION));
}

void initiate() {
    if (!glfwInit()) {
        fprintf(stderr, "Failed to initialize GLFW\n");
        exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
   
    screen.window = glfwCreateWindow(screen.width, screen.height, screen.title, NULL, NULL);
    if (!screen.window) {
        fprintf(stderr, "Failed to create window\n");
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());

    int windowPosX = (mode->width - screen.width) / 2;  
    int windowPosY = (mode->height - screen.height) / 2;  

    glfwSetWindowPos(screen.window, windowPosX, windowPosY);

    glfwMakeContextCurrent(screen.window);
    gladLoadGL(glfwGetProcAddress);
    glClearColor(0.7, 0.4, 0.1, 1.0);

    shaderProgram = loadShader("shaders/vertex.glsl", "shaders/fragment.glsl");
    glUseProgram(shaderProgram);

    viewLoc = glGetUniformLocation(shaderProgram, "view");

    if (viewLoc == -1) {
        fprintf(stderr, "Could not find uniform variable 'view'\n");
        exit(EXIT_FAILURE);
    }

    int projLoc = glGetUniformLocation(shaderProgram, "projection");
    if (projLoc == -1) {
        fprintf(stderr, "Could not find uniform variable 'projection'\n");
        exit(EXIT_FAILURE);
    }

    glfwSetInputMode(screen.window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    initFreeType(); 
    info();
}

void debug() {
    printf("View Matrix:\n");
    Matrix4x4 viewMatrix = getViewMatrix(&camera); 

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            printf("%f ", viewMatrix.data[i][j]); 
        }
        printf("\n");
    }
    printf("Camera Position: (%f, %f, %f)\n", camera.Position.x, camera.Position.y, camera.Position.z);
    printf("Camera Front: (%f, %f, %f)\n", camera.Front.x, camera.Front.y, camera.Front.z);
}

int main(int argc, char** argv) {
    setup();
    initiate();
    loop();
    end();
    return 0;
}
