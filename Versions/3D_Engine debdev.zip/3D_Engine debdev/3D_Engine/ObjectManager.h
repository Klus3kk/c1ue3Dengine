#pragma once
#include "3DObjects.h" 

typedef struct {
    Cube* cubes;
    int count;
    int capacity;
} CubeManager;

CubeManager cubeManager;

void initCubeManager();
void addCube();
void removeCube(int index);
void cleanupCubes();
void addCubeToManager(Cube newCube);