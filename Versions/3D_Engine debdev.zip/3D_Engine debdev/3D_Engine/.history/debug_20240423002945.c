#include "debug.h"
#include <stdio.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include "glad/glad.h"
#include "GLFW/glfw3.h"

FT_Library ft;
FT_Face face;
GLuint textShader;
GLuint textVAO, textVBO;

void initFreeType() {
    if (FT_Init_FreeType(&ft)) {
        fprintf(stderr, "Could not init FreeType Library\n");
        exit(1);
    }

    if (FT_New_Face(ft, "shaders/font/font.ttf", 0, &face)) {
        fprintf(stderr, "Failed to load font: %s\n", "shaders/font/font.ttf");
        exit(1);  // Exit if the font cannot be loaded
    }

    FT_Set_Pixel_Sizes(face, 0, 48); // This sets the font's width and height

    glGenVertexArrays(1, &textVAO);
    glGenBuffers(1, &textVBO);
    glBindVertexArray(textVAO);
    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), 0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    textShader = loadShader("shaders/vertex_font.glsl", "shaders/fragment_font.glsl");
}


void renderText(const char* text, float x, float y, float scale, Vector3 color) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    if (!face) {
        fprintf(stderr, "Font face not loaded.\n");
        return;
    }

    glUseProgram(textShader);
    glUniform3f(glGetUniformLocation(textShader, "textColor"), color.x, color.y, color.z);
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(textVAO);

    // Iterate through all characters
    for (const char* c = text; *c; c++) {
        if (FT_Load_Char(face, *c, FT_LOAD_RENDER)) {
            fprintf(stderr, "Failed to load Glyph: %c\n", *c);
            continue;
        }

        GLuint texture;
        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RED,
            face->glyph->bitmap.width,
            face->glyph->bitmap.rows,
            0,
            GL_RED,
            GL_UNSIGNED_BYTE,
            face->glyph->bitmap.buffer
        );

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        float xpos = x + face->glyph->bitmap_left * scale;
        float ypos = y - (face->glyph->bitmap.rows - face->glyph->bitmap_top) * scale;
        float w = face->glyph->bitmap.width * scale;
        float h = face->glyph->bitmap.rows * scale;

        float vertices[6][4] = {
            { xpos,     ypos + h,   0.0f, 0.0f },
            { xpos,     ypos,       0.0f, 1.0f },
            { xpos + w, ypos,       1.0f, 1.0f },
            { xpos,     ypos + h,   0.0f, 0.0f },
            { xpos + w, ypos,       1.0f, 1.0f },
            { xpos + w, ypos + h,   1.0f, 0.0f }
        };

        glBindBuffer(GL_ARRAY_BUFFER, textVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
        glBindTexture(GL_TEXTURE_2D, texture);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glBindTexture(GL_TEXTURE_2D, 0);
        glDeleteTextures(1, &texture);
        x += (face->glyph->advance.x >> 6) * scale;
    }
    glBindVertexArray(0);
}



void renderDebugInfo(const Camera* camera) {
    char debugInfo[256];
    sprintf_s(debugInfo, sizeof(debugInfo), "Camera Pos: (%.2f, %.2f, %.2f)",
        camera->Position.x, camera->Position.y, camera->Position.z);

    renderText(debugInfo, 25, 25, 1.0, (Vector3) { 1.0f, 1.0f, 1.0f });
}

void cleanupTextRendering() {
    FT_Done_Face(face);
    FT_Done_FreeType(ft);
}
