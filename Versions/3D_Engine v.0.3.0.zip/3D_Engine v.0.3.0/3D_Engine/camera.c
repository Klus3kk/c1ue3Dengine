#include "Camera.h"
#define M_PI 3.14159265358979323846
#include <stdbool.h>
#define FORWARD  1
#define BACKWARD 2
#define LEFT     3
#define RIGHT    4
#define SPACE    5
#define SHIFT    6

void updateCameraVectors(Camera* camera) {
    Vector3 front;
    front.x = cos(M_PI / 180.0 * camera->Yaw) * cos(M_PI / 180.0 * camera->Pitch);
    front.y = sin(M_PI / 180.0 * camera->Pitch);
    front.z = sin(M_PI / 180.0 * camera->Yaw) * cos(M_PI / 180.0 * camera->Pitch);
    camera->Front = vector_normalize(front);

    camera->Right = vector_normalize(vector_cross(camera->Front, camera->WorldUp));
    camera->Up = vector_normalize(vector_cross(camera->Right, camera->Front));
}


// The parameters will be changed in the future
void initCamera(Camera* camera) {
    camera->Position = vector(0.0f, 0.0f, 3.0f);
    camera->WorldUp = vector(0.0f, 1.0f, 0.0f);
    camera->Yaw = -90.0f;
    camera->Pitch = 0.0f;
    camera->MovementSpeed = 5.0f;
    camera->MouseSensitivity = 0.5f;
    camera->Zoom = 90.0f;
    camera->invertY = false;
    updateCameraVectors(camera);  // Initialize front, right, and up vectors
}

void processKeyboard(Camera* camera, int direction, float deltaTime) {
    float velocity = camera->MovementSpeed * deltaTime;
    if (direction == FORWARD)
        camera->Position = vector_add(camera->Position, vector_scale(camera->Front, velocity));
    if (direction == BACKWARD)
        camera->Position = vector_sub(camera->Position, vector_scale(camera->Front, velocity));
    if (direction == LEFT)
        camera->Position = vector_sub(camera->Position, vector_scale(camera->Right, velocity));
    if (direction == RIGHT)
        camera->Position = vector_add(camera->Position, vector_scale(camera->Right, velocity));
    if (direction == SPACE)
        camera->Position = vector_add(camera->Position, vector_scale(camera->Up, velocity));
    if (direction == SHIFT)
        camera->Position = vector_sub(camera->Position, vector_scale(camera->Up, velocity));
}

void processMouseMovement(Camera* camera, float xoffset, float yoffset, bool constrainPitch) {
    xoffset *= camera->MouseSensitivity;
    yoffset *= camera->MouseSensitivity;

    camera->Yaw += xoffset;
    camera->Pitch += (camera->invertY ? -1 : 1) * yoffset;

    if (constrainPitch) {
        if (camera->Pitch > 89.0f)
            camera->Pitch = 89.0f;
        if (camera->Pitch < -89.0f)
            camera->Pitch = -89.0f;
    }
    updateCameraVectors(camera);
}

void processMouseScroll(Camera* camera, float yoffset) { // Must fix this later
    camera->Zoom -= yoffset;
    if (camera->Zoom < 1.0f)
        camera->Zoom = 1.0f;
    if (camera->Zoom > 45.0f)
        camera->Zoom = 45.0f;
}

Matrix4x4 getViewMatrix(Camera* camera) {
    Vector3 zaxis = vector_normalize(vector_sub(camera->Position, vector_add(camera->Position, camera->Front))); // Forward
    Vector3 xaxis = vector_normalize(vector_cross(camera->Up, zaxis)); // Right
    Vector3 yaxis = vector_cross(zaxis, xaxis); // Up

    Matrix4x4 view = { 0 };
    view.data[0][0] = xaxis.x;
    view.data[0][1] = yaxis.x;
    view.data[0][2] = zaxis.x;
    view.data[0][3] = 0;

    view.data[1][0] = xaxis.y;
    view.data[1][1] = yaxis.y;
    view.data[1][2] = zaxis.y;
    view.data[1][3] = 0;

    view.data[2][0] = xaxis.z;
    view.data[2][1] = yaxis.z;
    view.data[2][2] = zaxis.z;
    view.data[2][3] = 0;

    view.data[3][0] = -vector_dot(xaxis, camera->Position);
    view.data[3][1] = -vector_dot(yaxis, camera->Position);
    view.data[3][2] = -vector_dot(zaxis, camera->Position);
    view.data[3][3] = 1;

    return view;
}

Matrix4x4 getProjectionMatrix(float fov, float aspectRatio, float nearPlane, float farPlane) {
    Matrix4x4 proj = { 0 };
    float rad = fov * (M_PI / 180.0f); // Convert degrees to radians directly
    float q = 1.0f / tan(rad * 0.5f);  // Calculate the cotangent of half the field of view angle
    float a = q / aspectRatio;
    float b = (nearPlane + farPlane) / (nearPlane - farPlane);
    float c = (2.0f * nearPlane * farPlane) / (nearPlane - farPlane);

    proj.data[0][0] = a;
    proj.data[1][1] = q;
    proj.data[2][2] = b;
    proj.data[2][3] = -1.0f;
    proj.data[3][2] = c;

    return proj;
}

Matrix4x4 translateMatrix(Vector3 position) {
    Matrix4x4 mat = { 0 };
    // Initialize as an identity matrix
    for (int i = 0; i < 4; i++) {
        mat.data[i][i] = 1.0f;
    }
    // Set translation components
    mat.data[3][0] = position.x;
    mat.data[3][1] = position.y;
    mat.data[3][2] = position.z;
    return mat;
}


Matrix4x4 matrixMultiply(Matrix4x4 a, Matrix4x4 b) {
    Matrix4x4 result = { 0 };
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            result.data[i][j] = 0;
            for (int k = 0; k < 4; k++) {
                result.data[i][j] += a.data[i][k] * b.data[k][j];
            }
        }
    }
    return result;
}
