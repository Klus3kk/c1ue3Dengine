#include "ObjectManager.h"
#include <stdlib.h>
#include "Camera.h"
#include "Vectors.h"
#include "textures.h"
#include "random_color.h"
ObjectManager objectManager;

void initObjectManager() {
    objectManager.capacity = 10;
    objectManager.objects = malloc(sizeof(Object3D) * objectManager.capacity);
    objectManager.count = 0;
}

void addObject(Camera* camera, ObjectType type, bool useTexture, int textureIndex, bool colorCreation) {
    float distanceInFront = 5.0f;
    Vector3 position = vector_add(camera->Position, vector_scale(camera->Front, 5.0f)); // 5.0f is the distance in front
    Vector4 color = (colorCreation) ? (Vector4) { randomFloat(), randomFloat(), randomFloat(), 1.0 } : (Vector4) { 1.0, 1.0, 1.0, 1.0 };

    Object3D newObject;
    newObject.position = position;
    newObject.type = type;
    newObject.useTexture = useTexture;
    newObject.color = color;  // Set color here, to be passed down

    switch (type) {
    case OBJ_CUBE:
        newObject.data.cube = createCube(position, color);
        break;
    case OBJ_SPHERE:
        newObject.data.sphere = createSphere(0.5f, 16, 8, position, color);
        break;
    case OBJ_PYRAMID:
        newObject.data.pyramid = createPyramid(position, color);
        break;
    case OBJ_CYLINDER:
        newObject.data.cylinder = createCylinder(0.5f, 1.0f, 8, position, color);
        break;
    }

    if (useTexture) {
        newObject.textureID = textures[textureIndex];  // Handle texture if used
    }

    addObjectToManager(newObject);
}




void removeObject(int index) {
    if (index < 0 || index >= objectManager.count) return;

    // Clean up based on type
    switch (objectManager.objects[index].type) {
    case OBJ_CUBE:
        destroyCube(&objectManager.objects[index].data.cube);
        break;
    case OBJ_SPHERE:
        destroySphere(&objectManager.objects[index].data.sphere);
        break;
    case OBJ_PYRAMID:
        destroyPyramid(&objectManager.objects[index].data.pyramid);
        break;
    case OBJ_CYLINDER:
        destroyCylinder(&objectManager.objects[index].data.cylinder);
        break;
    }

    // Shift remaining objects down in the array
    for (int i = index; i < objectManager.count - 1; i++) {
        objectManager.objects[i] = objectManager.objects[i + 1];
    }
    objectManager.count--;
}

void cleanupObjects() {
    for (int i = 0; i < objectManager.count; i++) {
        removeObject(i);
    }
    free(objectManager.objects);
    objectManager.objects = NULL;
    objectManager.count = 0;
    objectManager.capacity = 0;
}

void addObjectToManager(Object3D newObject) {
    if (objectManager.count >= objectManager.capacity) {
        objectManager.capacity *= 2;
        objectManager.objects = realloc(objectManager.objects, objectManager.capacity * sizeof(Object3D));
    }

    objectManager.objects[objectManager.count++] = newObject;
}

void drawObject(const Object3D* obj, const Matrix4x4 viewMatrix, const Matrix4x4 projMatrix) {
    switch (obj->type) {
    case OBJ_CUBE:
        drawCube(&obj->data.cube, viewMatrix, projMatrix);
        break;
    case OBJ_SPHERE:
        drawSphere(&obj->data.sphere, viewMatrix, projMatrix);
        break;
    case OBJ_PYRAMID:
        drawPyramid(&obj->data.pyramid, viewMatrix, projMatrix);
        break;
    case OBJ_CYLINDER:
        drawCylinder(&obj->data.cylinder, viewMatrix, projMatrix);
        break;
    }
}