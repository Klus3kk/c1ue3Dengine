//#include <GL/glew.h>
//#include <stdio.h>
//#include "loading.h" // Make sure this header declares the functions implemented here
//
//GLuint loadShader(const char* vertexPath, const char* fragmentPath); // Assuming this function loads and compiles shaders
//void checkGLEWError(GLuint shader, const char* type); // Assuming this function checks for shader compile/link errors
//
//// Initialize shader program and get uniform locations
//void setupShaderAndUniforms(GLuint* shaderProgram, int* viewLoc, int* projLoc) {
//    *shaderProgram = loadShader("shaders/vertex.glsl", "shaders/fragment.glsl");
//    if (!*shaderProgram) {
//        fprintf(stderr, "Shader failed to compile or link.\n");
//        return;
//    }
//
//    glUseProgram(*shaderProgram);
//
//    *viewLoc = glGetUniformLocation(*shaderProgram, "view");
//    if (*viewLoc == -1) {
//        fprintf(stderr, "Could not find uniform variable 'view'\n");
//    }
//
//    *projLoc = glGetUniformLocation(*shaderProgram, "projection");
//    if (*projLoc == -1) {
//        fprintf(stderr, "Could not find uniform variable 'projection'\n");
//    }
//}
//
//// Utility functions for setting uniforms
//void setUniformMatrix(GLuint location, const GLfloat* value) {
//    glUniformMatrix4fv(location, 1, GL_FALSE, value);
//}
//
//void setUniformInt(GLuint program, const char* name, GLint value) {
//    GLint loc = glGetUniformLocation(program, name);
//    glUniform1i(loc, value);
//}
//
//void useProgram(GLuint program) {
//    glUseProgram(program);
//}