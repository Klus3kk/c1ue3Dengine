#include <glad/glad.h>
#include "textures.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define MAX_TEXTURES 10  // Adjust based on how many textures you plan to use
GLuint textures[MAX_TEXTURES];  // Array to store texture IDs
GLuint loadTexture(const char* filename) {
    int width, height, nrChannels;
    unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
    if (!data) {
        fprintf(stderr, "Failed to load texture file %s\n", filename);
        return 0;
    }

    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, nrChannels == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    stbi_image_free(data);
    return textureID;
}


void loadAllTextures() {
    const char* textureFiles[] = {
        "resources/textures/blue.jpg",
    };
    int numTextures = sizeof(textureFiles) / sizeof(textureFiles[0]);
    for (int i = 0; i < numTextures; i++) {
        if (i < MAX_TEXTURES) {
            textures[i] = loadTexture(textureFiles[i]);
            if (textures[i] == 0) {
                fprintf(stderr, "Failed to load texture: %s\n", textureFiles[i]);
            }
        }
        else {
            fprintf(stderr, "Exceeded maximum texture limit of %d\n", MAX_TEXTURES);
            break;
        }
    }
}
