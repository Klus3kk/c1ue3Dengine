#include <glad/glad.h>
#define MAX_TEXTURES 10  // Adjust based on how many textures you plan to use
GLuint textures[MAX_TEXTURES];  // Array to store texture IDs
GLuint loadTexture(const char* filename);
void loadAllTextures();