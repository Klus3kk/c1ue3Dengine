#include <glad/glad.h>
float randomFloat();
void updateShaderColor(GLuint shaderProgram);