#pragma once
#include <SDL2/SDL.h>

typedef struct {
	float width, height, x, y;
} Square;

typedef struct {
	float width, height, x, y;
} Rect;

typedef struct {
	float width, height, x, y;
} Triangle;

typedef struct {
	float width, height, x, y;
} Circle;