//#include <GL/glew.h>
//void useProgram(GLuint program);
//void setUniformInt(GLuint program, const char* name, GLint value);
//void setUniformMatrix(GLuint location, const GLfloat* value);
//void setupShaderAndUniforms(GLuint* shaderProgram, int* viewLoc, int* projLoc);