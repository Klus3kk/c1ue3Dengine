#pragma once
#include "3DObjects.h" 
#include "Camera.h"
#include <stdbool.h>
typedef enum {
    OBJ_CUBE,
    OBJ_SPHERE,
    OBJ_PYRAMID,
    OBJ_CYLINDER
} ObjectType;

typedef struct {
    ObjectType type;
    union {
        Cube cube;
        Sphere sphere;
        Pyramid pyramid;
        Cylinder cylinder;
    } data;
    Vector3 position;
    Vector4 color;
    GLuint textureID;
    bool useTexture;
    bool useColor;
} Object3D;

typedef struct {
    Object3D* objects;
    int count;
    int capacity;
} ObjectManager;

extern ObjectManager objectManager;

void initObjectManager();
void addObject(Camera* camera, ObjectType type, bool useTexture, int textureIndex);
void removeObject(int index);
void cleanupObjects();
void addObjectToManager(Object3D newObject);
void drawObject(const Object3D* obj, const Matrix4x4 viewMatrix, const Matrix4x4 projMatrix);